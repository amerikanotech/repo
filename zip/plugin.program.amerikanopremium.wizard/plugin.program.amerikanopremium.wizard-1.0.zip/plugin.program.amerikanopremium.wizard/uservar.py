import os, xbmc, xbmcaddon

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = '[COLOR lightskyblue]Amerikano Premium Wizard[/COLOR]'
EXCLUDES       = [ADDON_ID]
# Text File with build info in it.
BUILDFILE      = 'https://cld.pt/dl/download/86dd06ce-b9ab-4a7a-a2ed-0afa673574c4/autobuildamerikano.txt?download=true'
# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.
APKFILE        = 'http://mediarepos.net/Repos/smashwiz/apks.txt'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = 'Amerikano Premium [COLOR red]YOU[/COLOR][COLOR white]TUBE[/COLOR] Videos'
YOUTUBEFILE    = 'https://'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = 'https://cld.pt/dl/download/c812ff4a-c876-4fe5-a959-30ea710ece80/addonsThe%20One.txt?download=true'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = 'https://cld.pt/dl/download/928e879c-3080-4732-99f1-620b828fdafd/krypton%20advanced.txt?download=true'

# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = 'https://cld.pt/dl/download/dab752ec-6ec3-46ab-9cbf-05b67e7c1f64/icon.png?download=true'
ICONMAINT      = 'https://cld.pt/dl/download/c43b5515-1639-4cf0-87e4-d427954fd228/maintenance.png?download=true'
ICONAPK        = 'https://cld.pt/dl/download/20eb2818-72ae-4d10-8ded-28576bfb10c9/apk.png?download=true'
ICONADDONS     = 'https://cld.pt/dl/download/80aa55e0-3d77-4b58-a36f-6969f642e797/addons.png?download=true'
ICONYOUTUBE    = 'https://cld.pt/dl/download/3fb5a638-aff1-4df8-ba3f-e4d449da879b/rea%20%282%29.png?download=true'
ICONSAVE       = 'https://cld.pt/dl/download/6bfebcf9-6fa8-4873-8bae-7c5db4df3b60/save.png?download=true'
ICONTRAKT      = 'https://cld.pt/dl/download/38b381eb-8673-49a8-8d42-a30dfa8c4440/track.png?download=true'
ICONREAL       = 'https://cld.pt/dl/download/853f618e-a49a-4fc5-abc2-1fe3cda363d4/Dynamic.png?download=true'
ICONLOGIN      = 'https://cld.pt/dl/download/f3dfed79-97fc-4342-ab21-3a2ab4625f7a/login.png?download=true'
ICONCONTACT    = 'https://cld.pt/dl/download/83366b9a-1ad4-4875-9bda-a59a1673e91c/ctt.png?download=true'
ICONSETTINGS   = 'https://cld.pt/dl/download/b5e4a76c-dc3b-434e-9833-d0e6f30e8c5a/Settings.png?download=true'
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '*'

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'dodgerblue'
COLOR2         = 'gold'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B][I][COLOR '+COLOR2+']Amerikano Premium[/COLOR][/B][/COLOR] [COLOR '+COLOR2+']%s[/COLOR][/I]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = 'Obrigado por escolher Amerikano Premium Wizard.\r\n\r\n Addon produzido por Amerikano Premium Contact us on Facebook - follow me on Twitter or visit our website at'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = 'https://cld.pt/dl/download/dab752ec-6ec3-46ab-9cbf-05b67e7c1f64/icon.png?download=true'
CONTACTFANART  = 'https://cld.pt/dl/download/c8c69602-e710-4b61-9271-adfa436fae28/kk.jpg?download=true'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'Yes'
# Url to wizard version
WIZARDFILE     = 'https://cld.pt/dl/download/86dd06ce-b9ab-4a7a-a2ed-0afa673574c4/autobuildamerikano.txt?download=true'
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'yes'
# Addon ID for the repository
REPOID         = 'Amerikanopremium'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'https:'
# Url to folder zip is located in
REPOZIPURL     = 'http://'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'https://cld.pt/dl/download/0aa0b240-69b1-496f-a51d-4b6c340f67a1/notifyamerikano.txt?download=true'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
HEADERMESSAGE  = 'Amerikano Premium wizard'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Background for Notification Window
BACKGROUND     = 'https://cld.pt/dl/download/df190bad-6b38-43df-af7f-6ea17e93cda9/fanart.png?download=true'
#########################################################